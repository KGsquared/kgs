manager login details

username: jaqueenwork@gmail.com
password: manager123




employee login details

username: mashilo@gmail.com
password: mashilo123