<!doctype html>
<!--
* Workday - A time clock application for employees
* Email: official.codefactor@gmail.com
* Version: 1.1
* Author: Brian Luna
* Copyright 2020 Codefactor
-->
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
        <meta name="viewport" content="width=device-width" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('/assets/images/img/favicon-16x16.png')); ?>">
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('/assets/images/img/favicon-32x32.png')); ?>">
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('/assets/images/img/favicon.ico')); ?>">

        <?php echo $__env->yieldContent('meta'); ?>

        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/vendor/semantic-ui/semantic.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/vendor/DataTables/datatables.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/vendor/flag-icon-css/css/flag-icon.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/css/style.css')); ?>">
        
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="<?php echo e(asset('/assets/vendor/html5shiv/html5shiv.min.js')); ?>></script>
            <script src="<?php echo e(asset('/assets/vendor/respond/respond.min.js')); ?>"></script>
        <![endif]-->

        <?php echo $__env->yieldContent('styles'); ?>
    </head>
    <body style="background:#0C356A;background-size: 100%">

        <div class="wrapper" >
        
        <nav id="sidebar" class="active" style="background:#F0DE36;background-size: 100%">
            <div class="sidebar-header bg-lightblue">
                <div class="logo">
                <a href="/" class="simple-text">
                    <img src="<?php echo e(asset('/assets/images/img/logo.png')); ?>">
                </a>
                </div>
            </div>

            <ul class="list-unstyled components">
                <li class="">
                    <a href="<?php echo e(url('dashboard')); ?>">
                        <i class="ui icon sliders horizontal"></i>
                        <p><?php echo e(__('Dashboard')); ?></p>
                    </a>
                </li>

                <li class="">
                    <a href="<?php echo e(url('employees')); ?>">
                        <i class="ui icon users"></i>
                        <p><?php echo e(__('Employees')); ?></p>
                    </a>
                </li>
                    
                <li class="">
                    <a href="<?php echo e(url('attendance')); ?>">
                        <i class="ui icon clock outline"></i>
                        <p><?php echo e(__('Attendances')); ?></p>
                    </a>
                </li>

                <li class="">
                    <a href="<?php echo e(url('schedules')); ?>">
                        <i class="ui icon calendar alternate outline"></i>
                        <p><?php echo e(__('Schedules')); ?></p>
                    </a>
                </li>
                
                <li class="">
                    <a href="<?php echo e(url('leaves')); ?>">
                        <i class="ui icon calendar plus outline"></i>
                        <p><?php echo e(__('Leave')); ?></p>
                    </a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('reports')); ?>">
                        <i class="ui icon chart bar outline"></i>
                        <p><?php echo e(__('Reports')); ?></p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('users')); ?>">
                        <i class="ui icon user circle outline"></i>
                        <p><?php echo e(__('Users')); ?></p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('settings')); ?>">
                        <i class="ui icon cog"></i>
                        <p><?php echo e(__('Settings')); ?></p>
                    </a>
                </li>
            </ul>
        </nav>

        <div id="body" class="active" style="background:#7C9D96;background-size: 100%">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="slidesidebar" class="ui icon button btn-light-outline">
                        <i class="ui icon bars"></i> <span class="toggle-sidebar-menu"><?php echo e(__('Menu')); ?></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="nav navbar-nav ml-auto navmenu">
                            <li class="nav-item">
                                <div class="ui pointing link dropdown item" tabindex="0">
                                    <i class="ui icon flag"></i> <span class="navmenutext uppercase"><?php echo e(env('APP_LOCALE', 'en')); ?></span>
                                    <i class="dropdown icon"></i>
                                    <div class="menu" tabindex="-1">
                                      <a href="<?php echo e(url('lang/en')); ?>" class="item"><i class="flag-icon flag-icon-us"></i>English</a>
                                      <a href="<?php echo e(url('lang/es')); ?>" class="item"><i class="flag-icon flag-icon-es"></i>Español</a>
                                      <a href="<?php echo e(url('lang/fr')); ?>" class="item"><i class="flag-icon flag-icon-fr"></i>Français</a>
                                      <a href="<?php echo e(url('lang/de')); ?>" class="item"><i class="flag-icon flag-icon-de"></i>Deutsch</a>
                                      <a href="<?php echo e(url('lang/jp')); ?>" class="item"><i class="flag-icon flag-icon-jp"></i>日本語</a>
                                      <a href="<?php echo e(url('lang/in')); ?>" class="item"><i class="flag-icon flag-icon-in"></i>Hindi</a>
                                      <a href="<?php echo e(url('lang/it')); ?>" class="item"><i class="flag-icon flag-icon-it"></i>Italian</a>
                                      <a href="<?php echo e(url('lang/kr')); ?>" class="item"><i class="flag-icon flag-icon-kr"></i>한국말</a>
                                      <a href="<?php echo e(url('lang/my')); ?>" class="item"><i class="flag-icon flag-icon-my"></i>Malay</a>
                                      <a href="<?php echo e(url('lang/nl')); ?>" class="item"><i class="flag-icon flag-icon-nl"></i>Dutch</a>
                                      <a href="<?php echo e(url('lang/ph')); ?>" class="item"><i class="flag-icon flag-icon-ph"></i>Filipino</a>
                                      <a href="<?php echo e(url('lang/pt')); ?>" class="item"><i class="flag-icon flag-icon-pt"></i>Português</a>
                                    </div>
                              </div>
                            </li>
                            <li class="nav-item">
                                <div class="ui pointing link dropdown item" tabindex="0">
                                    <i class="ui icon linkify"></i> <span class="navmenutext uppercase"><?php echo e(__('Quick Access')); ?></span>
                                    <i class="dropdown icon"></i>
                                    <div class="menu" tabindex="-1">
                                      <a href="<?php echo e(url('clock')); ?>" target="_blank" class="item"><i class="ui icon clock outline"></i><?php echo e(__('Clock In/Out')); ?></a>
                                      <div class="divider"></div>
                                      <a href="<?php echo e(url('employees/new')); ?>" class="item"><i class="ui icon user plus"></i><?php echo e(__('New Employee')); ?></a>
                                      <div class="divider"></div>
                                      <a href="<?php echo e(url('fields/company')); ?>" class="item"><i class="ui icon university"></i><?php echo e(__('Company')); ?></a>
                                      <a href="<?php echo e(url('fields/department')); ?>" class="item"><i class="ui icon cubes"></i><?php echo e(__('Department')); ?></a>
                                      <a href="<?php echo e(url('fields/jobtitle')); ?>" class="item"><i class="ui icon pencil alternate"></i><?php echo e(__('Job Title')); ?></a>
                                      <a href="<?php echo e(url('fields/leavetype')); ?>" class="item"><i class="ui icon calendar alternate outline"></i><?php echo e(__('Leave Type')); ?></a>
                                    </div>
                              </div>
                            </li>
                            <li class="nav-item">
                               <div class="ui pointing link dropdown item" tabindex="0">
                                    <i class="ui icon user outline"></i> <span class="navmenutext"><?php if(isset(Auth::user()->name)): ?><?php echo e(Auth::user()->name); ?><?php endif; ?></span>
                                    <i class="dropdown icon"></i>
                                    <div class="menu" tabindex="-1">
                                      <a href="<?php echo e(url('update-profile')); ?>" class="item"><i class="ui icon user"></i><?php echo e(__('Update Account')); ?></a>
                                      <a href="<?php echo e(url('update-password')); ?>" class="item"><i class="ui icon lock"></i><?php echo e(__('Change Password')); ?></a>
                                      <a href="<?php echo e(url('personal/dashboard')); ?>" target="_blank" class="item"><i class="ui icon sign-in"></i><?php echo e(__('Switch to MyAccount')); ?></a>
                                      <div class="divider"></div>
                                      <a href="<?php echo e(url('logout')); ?>" class="item"><i class="ui icon power"></i><?php echo e(__('Logout')); ?></a>
                                    </div>
                                </div>
                            </li>

                        </ul>
                    </div>
                </div>
            </nav>

            <div class="content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>

            <input type="hidden" id="_url" value="<?php echo e(url('/')); ?>">
            <script>
                var y = '<?php if(isset($var)): ?><?php echo e($var); ?><?php endif; ?>';
            </script>
        </div>
    </div>

    <script src="<?php echo e(asset('/assets/vendor/jquery/jquery-3.4.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/semantic-ui/semantic.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/bootstrap-notify/bootstrap-notify.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/DataTables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/script.js')); ?>"></script>
    <?php if($success = Session::get('success')): ?>
    <script>
        $(document).ready(function() {
            $.notify({
                icon: 'ui icon check',
                message: "<?php echo e($success); ?>"},
                {type: 'success',timer: 400}
            );
        });
    </script>
    <?php endif; ?>
    
    <?php if($error = Session::get('error')): ?>
    <script>
        $(document).ready(function() {
            $.notify({
                icon: 'ui icon times',
                message: "<?php echo e($error); ?>"},
                {type: 'danger',timer: 400});
        });
    </script>
    <?php endif; ?>

    <?php echo $__env->yieldContent('scripts'); ?>

    </body>
</html><?php /**PATH C:\xampp\htdocs\TimeClockApplication\application\resources\views/layouts/default.blade.php ENDPATH**/ ?>