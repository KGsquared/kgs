    
    <?php $__env->startSection('meta'); ?>
        <title>Edit Leave of Absence | Workday Time Clock</title>
        <meta name="description" content="Workday edit employee leave of absence.">
    <?php $__env->stopSection(); ?> 

    <?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h2 class="page-title"><?php echo e(__("Edit Leave")); ?></h2>
            </div>    
        </div>

        <div class="row">
        <div class="col-md-12">
            <div class="box box-success">
                <div class="box-content">
                <?php if($errors->any()): ?>
                <div class="ui error message">
                    <i class="close icon"></i>
                    <div class="header"><?php echo e(__("There were some errors with your submission")); ?></div>
                    <ul class="list">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <form id="edit_leave_form" action="<?php echo e(url('leaves/update')); ?>" class="ui form" method="post" accept-charset="utf-8">
                <?php echo csrf_field(); ?>
                    <div class="field">
                        <label><?php echo e(__("Employee")); ?></label>
                        <input type="text" class="readonly" readonly="" value="<?php if(isset($l->employee)): ?><?php echo e($l->employee); ?><?php endif; ?>">
                    </div>
                    <div class="field">
                        <label><?php echo e(__("Leave Type")); ?></label>
                        <input type="text" class="readonly" readonly="" value="<?php if(isset($l->type)): ?><?php echo e($l->type); ?><?php endif; ?>">
                    </div>
                    <div class="two fields">
                        <div class="field">
                            <label for=""><?php echo e(__("Leave From")); ?></label>
                            <input type="text" class="readonly" readonly="" value="<?php if(isset($l->leavefrom)): ?><?php echo e($l->leavefrom); ?><?php endif; ?>"/>
                        </div>
                        <div class="field">
                            <label for=""><?php echo e(__("Leave To")); ?></label>
                            <input type="text" class="readonly" readonly="" value="<?php if(isset($l->leaveto)): ?><?php echo e($l->leaveto); ?><?php endif; ?>"/>
                        </div>
                    </div>
                    <div class="field">
                        <label for=""><?php echo e(__("Return Date")); ?></label>
                        <input id="returndate" type="text" class="readonly" readonly="" value="<?php if(isset($l->returndate)): ?><?php echo e($l->returndate); ?><?php endif; ?>"/>
                    </div>
                    <div class="field">
                        <label><?php echo e(__("Reason")); ?></label>
                        <textarea class="uppercase readonly" readonly="" rows="5"><?php if(isset($l->reason)): ?><?php echo e($l->reason); ?><?php endif; ?></textarea>
                    </div>
                    <div class="field">
                        <p class="ui horizontal divider tiny sub header"><?php echo e(__("Manager Privilege")); ?></p>
                    </div>
                    <div class="field">
                        <label><?php echo e(__("Status")); ?></label>
                        <select class="ui dropdown uppercase" name="status">
                            <option value="Approved" <?php if(isset($l->status)): ?> <?php if($l->status == 'Approved'): ?> selected <?php endif; ?> <?php endif; ?>>Approved</option>
                            <option value="Pending" <?php if(isset($l->status)): ?> <?php if($l->status == 'Pending'): ?> selected <?php endif; ?> <?php endif; ?>>Pending</option>
                            <option value="Declined" <?php if(isset($l->status)): ?> <?php if($l->status == 'Declined'): ?> selected <?php endif; ?> <?php endif; ?>>Declined</option>
                        </select>
                    </div>
                    <div class="field">
                        <label><?php echo e(__("Add Comment (Optional)")); ?></label>
                        <textarea name="comment" class="uppercase" rows="5"><?php if(isset($l->comment)): ?><?php echo e($l->comment); ?><?php endif; ?></textarea>
                    </div>
                    <div class="ui error message">
                        <i class="close icon"></i>
                        <div class="header"></div>
                        <ul class="list">
                            <li class=""></li>
                        </ul>
                    </div>
                </div>
                <div class="box-footer">
                    <input type="hidden" class="readonly" readonly="" name="id" value="<?php if(isset($e_id)): ?><?php echo e($e_id); ?><?php endif; ?>">
                    <button class="ui positive small button" type="submit" name="submit"><i class="ui checkmark icon"></i> <?php echo e(__("Update")); ?></button>
                    <a href="<?php echo e(url('leaves')); ?>" class="ui black grey small button"><i class="ui times icon"></i> <?php echo e(__("Cancel")); ?></a>
                </div>
                </form>
                
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TimeClockApplication\application\resources\views/admin/edits/edit-leaves.blade.php ENDPATH**/ ?>