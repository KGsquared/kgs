    
    <?php $__env->startSection('meta'); ?>
        <title>Edit Employee Profile | Workday Time Clock</title>
        <meta name="description" content="Workday edit employee profile.">
    <?php $__env->stopSection(); ?> 

    <?php $__env->startSection('styles'); ?>
        <link href="<?php echo e(asset('/assets/vendor/air-datepicker/dist/css/datepicker.min.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h2 class="page-title"><?php echo e(__('Edit Employee Profile')); ?>

                    <a href="<?php echo e(url('employees')); ?>" class="ui basic blue button mini offsettop5 float-right"><i class="ui icon chevron left"></i><?php echo e(__('Return')); ?></a>
                </h2>
            </div>    
        </div>

        <div class="col-md-12">
            <?php if($errors->any()): ?>
            <div class="ui error message">
                <i class="close icon"></i>
                <div class="header"><?php echo e(__('There were some errors with your submission')); ?></div>
                <ul class="list">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>

        <div class="row">
            <form id="edit_employee_form" action="<?php echo e(url('profile/update')); ?>" class="ui form custom" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="col-md-6 float-left">
                    <div class="box box-success">
                        <div class="box-header with-border"><?php echo e(__('Personal Information')); ?></div>
                        <div class="box-body">
                            <div class="two fields">
                                <div class="field">
                                    <label><?php echo e(__('First Name')); ?></label>
                                    <input type="text" class="uppercase" name="firstname" value="<?php if(isset($person_details->firstname)): ?><?php echo e($person_details->firstname); ?><?php endif; ?>">
                                </div>
                                <div class="field">
                                    <label><?php echo e(__('Middle Name')); ?></label>
                                    <input type="text" class="uppercase" name="mi" value="<?php if(isset($person_details->mi)): ?><?php echo e($person_details->mi); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="field">
                                <label><?php echo e(__('Last Name')); ?></label>
                                <input type="text" class="uppercase" name="lastname" value="<?php if(isset($person_details->lastname)): ?><?php echo e($person_details->lastname); ?><?php endif; ?>">
                            </div>
                            <div class="field">
                                <label><?php echo e(__('Gender')); ?></label>
                                <select name="gender" class="ui dropdown uppercase">
                                    <option value="">Select Gender</option>
                                    <option value="MALE" <?php if(isset($person_details->gender)): ?> <?php if($person_details->gender == 'MALE'): ?> selected <?php endif; ?> <?php endif; ?>>MALE</option>
                                    <option value="FEMALE" <?php if(isset($person_details->gender)): ?> <?php if($person_details->gender == 'FEMALE'): ?> selected <?php endif; ?> <?php endif; ?>>FEMALE</option>
                                </select>
                            </div>
                            <div class="field">
                                <label><?php echo e(__('Civil Status')); ?></label>
                                <select name="civilstatus" class="ui dropdown uppercase">
                                    <option value="">Select Civil Status</option>
                                    <option value="SINGLE" <?php if(isset($person_details->civilstatus)): ?> <?php if($person_details->civilstatus == 'SINGLE'): ?> selected <?php endif; ?> <?php endif; ?>>SINGLE</option>
                                    <option value="MARRIED" <?php if(isset($person_details->civilstatus)): ?> <?php if($person_details->civilstatus == 'MARRIED'): ?> selected <?php endif; ?> <?php endif; ?>>MARRIED</option>
                                    <option value="ANULLED" <?php if(isset($person_details->civilstatus)): ?> <?php if($person_details->civilstatus == 'ANULLED'): ?> selected <?php endif; ?> <?php endif; ?>>ANULLED</option>
                                    <option value="WIDOWED" <?php if(isset($person_details->civilstatus)): ?> <?php if($person_details->civilstatus == 'WIDOWED'): ?> selected <?php endif; ?> <?php endif; ?>>WIDOWED</option>
                                    <option value="LEGALLY SEPARATED" <?php if(isset($person_details->civilstatus)): ?> <?php if($person_details->civilstatus == 'LEGALLY SEPARATED'): ?> selected <?php endif; ?> <?php endif; ?>>LEGALLY SEPARATED</option>
                                </select>
                            </div>
                            <div class="two fields">
                                <div class="field">
                                    <label><?php echo e(__('Height')); ?> <span class="help">(cm)</span></label>
                                    <input type="text" name="height" value="<?php if(isset($person_details->height)): ?><?php echo e($person_details->height); ?><?php endif; ?>" placeholder="000">
                                </div>
                                <div class="field">
                                    <label><?php echo e(__('Weight')); ?> <span class="help">(pounds)</span></label>
                                    <input type="text" name="weight" value="<?php if(isset($person_details->weight)): ?><?php echo e($person_details->weight); ?><?php endif; ?>" placeholder="000">
                                </div>
                            </div>
                            <div class="two fields">
                            <div class="field">
                                <label><?php echo e(__('Email Address (Personal)')); ?></label>
                                <input type="email" name="emailaddress" value="<?php if(isset($person_details->emailaddress)): ?><?php echo e($person_details->emailaddress); ?><?php endif; ?>" class="lowercase">
                            </div>
                            <div class="field">
                                <label><?php echo e(__('Mobile Number')); ?></label>
                                <input type="text" class="uppercase" name="mobileno" value="<?php if(isset($person_details->mobileno)): ?><?php echo e($person_details->mobileno); ?><?php endif; ?>">
                            </div>
                            </div>
                            <div class="two fields">
                                <div class="field">
                                    <label><?php echo e(__('Age')); ?></label>
                                    <input type="text" name="age" value="<?php if(isset($person_details->age)): ?><?php echo e($person_details->age); ?><?php endif; ?>" placeholder="00">
                                </div>
                                <div class="field">
                                    <label><?php echo e(__('Date of Birth')); ?></label>
                                    <input type="text" name="birthday" value="<?php if(isset($person_details->birthday)): ?><?php echo e($person_details->birthday); ?><?php endif; ?>" class="airdatepicker" placeholder="Date">
                                </div>
                            </div>
                            <div class="field">
                                <label><?php echo e(__('National ID')); ?></label>
                                <input type="text" class="uppercase" name="nationalid" value="<?php if(isset($person_details->nationalid)): ?><?php echo e($person_details->nationalid); ?><?php endif; ?>" placeholder="">
                            </div>
                            <div class="field">
                                <label><?php echo e(__('Place of Birth')); ?></label>
                                <input type="text" class="uppercase" name="birthplace" value="<?php if(isset($person_details->birthplace)): ?><?php echo e($person_details->birthplace); ?><?php endif; ?>" placeholder="City, Province, Country">
                            </div>
                            <div class="field">
                                <label><?php echo e(__('Home Address')); ?></label>
                                <input type="text" class="uppercase" name="homeaddress" value="<?php if(isset($person_details->homeaddress)): ?><?php echo e($person_details->homeaddress); ?><?php endif; ?>" placeholder="House/Unit Number, Building, Street, City, Province, Country">
                            </div>
                            <div class="field">
                                <label><?php echo e(__('Upload Profile photo')); ?></label>
                                <input class="ui file upload" value="" id="imagefile" name="image" type="file" accept="image/png, image/jpeg, image/jpg" onchange="validateFile()">
                            </div>
                            <br>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 float-left">
                    <div class="box box-success">
                        <div class="box-header with-border"><?php echo e(__('Employee Details')); ?></div>
                        <div class="box-body">
                            <h4 class="ui dividing header"><?php echo e(__('Designation')); ?></h4>
                            <div class="field">
                                <label><?php echo e(__('Company')); ?></label>
                                <select name="company" class="ui search dropdown uppercase">
                                    <option value="">Select Company</option>
                                    <?php if(isset($company)): ?>
                                        <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($data->company); ?>" <?php if($data->company == $company_details->company): ?> selected <?php endif; ?>> <?php echo e($data->company); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="field">
                                <label><?php echo e(__('Department')); ?></label>
                                <select name="department" class="ui search dropdown uppercase department">
                                    <option value="">Select Department</option>
                                    <?php if(isset($department)): ?>
                                        <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($data->department); ?>" <?php if($data->department == $company_details->department): ?> selected <?php endif; ?>> <?php echo e($data->department); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="field">
                                <label><?php echo e(__('Job Title / Position')); ?></label>
                                <div class="ui search dropdown selection uppercase jobposition">
                                    <input type="hidden" name="jobposition" value="<?php echo e($company_details->jobposition); ?>">
                                    <i class="dropdown icon"></i>
                                    <div class="text"><?php echo e($company_details->jobposition); ?></div>
                                    <div class="menu">
                                    <?php if(isset($jobtitle)): ?>
                                        <?php if(isset($department)): ?>
                                            <?php $__currentLoopData = $jobtitle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($dept->id == $data->dept_code): ?>
                                                        <div class="item" data-value="<?php echo e($data->jobtitle); ?>" data-dept="<?php echo e($dept->department); ?>" <?php if($data->jobtitle == $company_details->jobposition): ?> selected <?php endif; ?>><?php echo e($data->jobtitle); ?></div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="field">
                                <label><?php echo e(__('ID Number')); ?></label>
                                <input type="text" class="uppercase" name="idno" value="<?php if(isset($company_details->idno)): ?><?php echo e($company_details->idno); ?><?php endif; ?>">
                            </div>
                            <div class="field">
                                <label><?php echo e(__('Email Address (Company)')); ?></label>
                                <input type="email" name="companyemail" value="<?php if(isset($company_details->companyemail)): ?><?php echo e($company_details->companyemail); ?><?php endif; ?>" class="lowercase">
                            </div>
                            <div class="field">
                                <label><?php echo e(__('Leave Privileges')); ?></label>
                                <select name="leaveprivilege" class="ui dropdown uppercase">
                                    <option value="">Select Leave Privilege</option>
                                    <?php if(isset($leavegroup)): ?> 
                                        <?php $__currentLoopData = $leavegroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($lg->id); ?>" <?php if(isset($company_details->leaveprivilege)): ?> <?php if($lg->id == $company_details->leaveprivilege): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($lg->leavegroup); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <h4 class="ui dividing header"><?php echo e(__('Employment Information')); ?></h4>
                            <div class="field">
                                <label><?php echo e(__('Employment Type')); ?></label>
                                <select name="employmenttype" class="ui dropdown uppercase">
                                    <option value="">Select Type</option>
                                    <option value="Regular" <?php if(isset($person_details->employmenttype)): ?> <?php if($person_details->employmenttype == 'Regular'): ?> selected <?php endif; ?> <?php endif; ?>>Regular</option>
                                    <option value="Trainee" <?php if(isset($person_details->employmenttype)): ?> <?php if($person_details->employmenttype == 'Trainee'): ?> selected <?php endif; ?> <?php endif; ?>>Trainee</option>
                                </select>
                            </div>
                            <div class="field">
                                <label><?php echo e(__('Employment Status')); ?></label>
                                <select name="employmentstatus" class="ui dropdown uppercase">
                                    <option value="">Select Status</option>
                                    <option value="Active" <?php if(isset($person_details->employmentstatus)): ?> <?php if($person_details->employmentstatus == 'Active'): ?> selected <?php endif; ?> <?php endif; ?>>Active</option>
                                    <option value="Archived" <?php if(isset($person_details->employmentstatus)): ?> <?php if($person_details->employmentstatus == 'Archived'): ?> selected <?php endif; ?> <?php endif; ?>>Archived</option>
                                </select>
                            </div>
                            <div class="field">
                                <label><?php echo e(__('Official Start Date')); ?></label>
                                <input type="text" name="startdate" value="<?php if(isset($company_details->startdate)): ?><?php echo e($company_details->startdate); ?><?php endif; ?>" class="airdatepicker" placeholder="Date">
                            </div>
                            <div class="field">
                                <label><?php echo e(__('Date Regularized')); ?></label>
                                <input type="text" name="dateregularized" value="<?php if(isset($company_details->dateregularized)): ?><?php echo e($company_details->dateregularized); ?><?php endif; ?>" class="airdatepicker" placeholder="Date">
                            </div>
                            <br>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 float-left">
                    <div class="ui error message">
                        <i class="close icon"></i>
                        <div class="header"></div>
                        <ul class="list">
                            <li class=""></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-12 float-left">
                    <div class="action align-right">
                        <input type="hidden" name="id" value="<?php if(isset($e_id)): ?><?php echo e($e_id); ?><?php endif; ?>">
                        <button type="submit" name="submit" class="ui green button small"><i class="ui checkmark icon"></i> <?php echo e(__('Update')); ?></button>
                        <a href="<?php echo e(url('employees')); ?>" class="ui grey button small"><i class="ui times icon"></i> <?php echo e(__('Cancel')); ?></a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('/assets/vendor/air-datepicker/dist/js/datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/air-datepicker/dist/js/i18n/datepicker.en.js')); ?>"></script>
    
    <script type="text/javascript">
        $('.airdatepicker').datepicker({ language: 'en', dateFormat: 'yyyy-mm-dd' });
        $('.ui.dropdown.department').dropdown({ onChange: function(value, text, $selectedItem) {
            $('.jobposition .menu .item').addClass('hide');
            $('.jobposition .text').text('');
            $('input[name="jobposition"]').val('');
            $('.jobposition .menu .item').each(function() {
                var dept = $(this).attr('data-dept');
                if(dept == value) {$(this).removeClass('hide');};
            });
        }});

        function validateFile() {
            var f = document.getElementById("imagefile").value;
            var d = f.lastIndexOf(".") + 1;
            var ext = f.substr(d, f.length).toLowerCase();
            if (ext == "jpg" || ext == "jpeg" || ext == "png") { } else {
                document.getElementById("imagefile").value="";
                $.notify({
                icon: 'ui icon times',
                message: "Please upload only jpg/jpeg and png image formats."},
                {type: 'danger',timer: 400});
            }
        }

        var selected = "<?php if(isset($company_details->leaveprivilege)): ?><?php echo e($company_details->leaveprivilege); ?><?php endif; ?>";
        var items = selected.split(',');
        $('.ui.dropdown.multiple.leaves').dropdown('set selected', items);
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TimeClockApplication\application\resources\views/admin/edits/edit-personal-info.blade.php ENDPATH**/ ?>