    <?php $__env->startSection('meta'); ?>
        <title>Leave of Absence | Workday Time Clock</title>
        <meta name="description" content="Workday leave of absence, view all employee leaves of absence, edit, comment, and approve or deny leave requests.">
    <?php $__env->stopSection(); ?> 

    <?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <h2 class="page-title"><?php echo e(__('Leaves of Absence')); ?></h2>
        </div>

        <div class="row">
            <div class="box box-success">
                <div class="box-body">
                    <table width="100%" class="table table-striped table-hover" id="dataTables-example" data-order='[[ 0, "asc" ]]'>
                        <thead>
                            <tr>
                                <th><?php echo e(__('Employee')); ?></th>
                                <th><?php echo e(__('Description')); ?></th>
                                <th><?php echo e(__('Leave From')); ?></th>
                                <th><?php echo e(__('Leave To')); ?></th>
                                <th><?php echo e(__('Return Date')); ?></th>
                                <th><?php echo e(__('Status')); ?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($leaves)): ?>
                                <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($data->employee); ?></td>
                                    <td><?php echo e($data->type); ?></td>
                                    <td><?php echo e(date('D, M d, Y', strtotime($data->leavefrom))) ?></td>
                                    <td><?php echo e(date('D, M d, Y', strtotime($data->leaveto))) ?></td>
                                    <td><?php echo e(date('M d, Y', strtotime($data->returndate))) ?></td>
                                    <td><span class=""><?php echo e($data->status); ?></span></td>
                                    <td class="align-right">
                                        <a href="<?php echo e(url('leaves/edit/'.$data->id)); ?>" class="ui circular basic icon button tiny"><i class="icon edit outline"></i></a>
                                        <a href="<?php echo e(url('leaves/delete/'.$data->id)); ?>" class="ui circular basic icon button tiny"><i class="icon trash alternate outlin"></i></a>
                                    
                                        <?php if(isset($data->comment)): ?>
                                            <?php if($data->comment != null): ?>
                                                <button class="ui circular basic icon button tiny uppercase" data-tooltip='<?php echo e($data->comment); ?>' data-variation='wide' data-position='top right'><i class="ui icon comment alternate"></i></button>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: true,ordering: true});
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TimeClockApplication\application\resources\views/admin/leaves.blade.php ENDPATH**/ ?>